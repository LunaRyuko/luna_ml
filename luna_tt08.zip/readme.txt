Custom assets are in materials, models and sound.

VMFs are in mapsrc

Asset Sources are in textures and maya

All assets are either mine or Valve's